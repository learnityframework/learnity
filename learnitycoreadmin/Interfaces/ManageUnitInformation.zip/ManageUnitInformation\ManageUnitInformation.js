function upload_onclick(){
	var unit_id=getValue('unit_id');
	if(unit_id!=0){
		var file = getValue('BrowseFile');
		if(file.value!=""){
			ladminTree.uploadtorepository(unit_id,file,function(data) {
				setReloadGrid('ManageUnitInformationGrid');
				$.blockUI({message: data});
				setTimeout($.unblockUI, 1000);
			});
		}
		else{
		alert("Pleare Select a file");
		}
	}
	else{
		alert("Pleare Select an Unit Name");
	}
	
}

function download_onclick(){
	var unit_id=getValue('unit_id');
	if(unit_id!=0){
		ladminTree.downloadfromrepository(unit_id,function(data){
			window.open(data);	
		});
	}
	else{
		alert("Please Select an Unit Name");
	}
}