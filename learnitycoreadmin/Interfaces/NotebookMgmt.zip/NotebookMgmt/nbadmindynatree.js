NoteBookUtil.getDetailsNote(dtnode.data.description,function(data) {
	setValue('showdetails',data)
});
setValue('subjectfield',"");
setValue('notes',"");
setValue('attachment',"");