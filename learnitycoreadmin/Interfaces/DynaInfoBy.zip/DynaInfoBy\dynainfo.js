
function onload_onclick()
{
	Portal.getRowDynaInfo(function(data) 
	{
	});
}