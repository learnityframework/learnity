	
function forum_id() {
	var forum_id=getValue("selectforum");
	return forum_id;	
}



		



