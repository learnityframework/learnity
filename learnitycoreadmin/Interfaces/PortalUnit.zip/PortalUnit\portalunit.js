function page_load() {
	Portal.selfRegistration(function(data) {
		setValue('PortalUnit_selfregister',data);
	});
}
function selfRegistration_onClick()
{
	
	
	window.open('./interfaceenginev2.PortalServlet?IID=LOSelfRegistration','selfregistration','width=910,height=500,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
	
}
