function onload_click() {
			$("#ladminTree").dynatree({
				title: "Sample",
				autoCollapse: 'true',
				keyboard: 'true',
				onActivate: function(dtnode) {
					$("#ladminTitle").text(dtnode.data.title);
					f12(dtnode);
					},
					children: [
					{title: "Training Management",isFolder: true,url:'',
						children: [
						{title: "Location Administration",isFolder: true,url:'',
							children: [
								{title:'Location Type Management',url:'./interfaceenginev2.PortalServlet?IID=TrainingLocationType' ,isFolder: false},
								{title:'Location Management',url:'./interfaceenginev2.PortalServlet?IID=TrainingLocationMgmt' ,isFolder: false}
							]
							},
							{title: "Resource Administration",isFolder: true,url:'',
							children: [
								{title:'Category Management',url:'./interfaceenginev2.PortalServlet?IID=ResourceCategoryMgmt' ,isFolder: false},
								{title:'Resource Management',url:'./interfaceenginev2.PortalServlet?IID=ResourceManagement' ,isFolder: false},
								{title:'Resource Schedule View',url:'./interfaceenginev2.PortalServlet?IID=TrainingResourceScheduleView' ,isFolder: false}
							]
							},
							{title: "Training Administration",isFolder: true,url:'',
							children: [
								{title:'Provider Management',url:'./interfaceenginev2.PortalServlet?IID=TrainingProviderMgmt' ,isFolder: false},
								{title:'Period Management',url:'./interfaceenginev2.PortalServlet?IID=TrainingPeriodMgmt' ,isFolder: false},
								{title:'Program Type Management',url:'./interfaceenginev2.PortalServlet?IID=ProgramTypeManagement' ,isFolder: false},
								{title:'Program Instance Management',url:'./interfaceenginev2.PortalServlet?IID=ProgramInstanceManagement' ,isFolder: false},
								{title:'Program Course Association',url:'./interfaceenginev2.PortalServlet?IID=ProgramCourseAssociation' ,isFolder: false},
								{title:'Program Assessment Association',url:'./interfaceenginev2.PortalServlet?IID=ProgramAssessmentAssociation' ,isFolder: false},
								{title:'Program Instance Resource Management',url:'./interfaceenginev2.PortalServlet?IID=ProgramInstanceResourceManagement' ,isFolder: false},
								{title:'Program Instance Schedule Management',url:'./interfaceenginev2.PortalServlet?IID=ProgramInstanceScheduleMgmt' ,isFolder: false},
								{title:'Plan Management',url:'./interfaceenginev2.PortalServlet?IID=PlanManagement' ,isFolder: false},
								{title:'Plan Detail Management',url:'./interfaceenginev2.PortalServlet?IID=PlanDetailManagement' ,isFolder: false},
								{title:'Employee Plan Association',url:'./interfaceenginev2.PortalServlet?IID=EmployeePlanAssociation' ,isFolder: false},
								{title:'Group Plan Association',url:'./interfaceenginev2.PortalServlet?IID=PlanGroupAssociation' ,isFolder: false},
								{title:'Pre-Post Evaluation Management',url:'./interfaceenginev2.PortalServlet?IID=PrePostEvaluationManagement' ,isFolder: false},
								{title:'Approval Management',url:'./interfaceenginev2.PortalServlet?IID=ApprovalManagement' ,isFolder: false},
								{title:'Training Evaluation Management',url:'./interfaceenginev2.PortalServlet?IID=TrainingEvaluationManagement' ,isFolder: false},
								{title:'Record Management',url:'./interfaceenginev2.PortalServlet?IID=RecordManagement' ,isFolder: false},
								{title:'Help',url:'./interfaceenginev2.PortalServlet?IID=TrainingAdministrationHelp' ,isFolder: false}
							]
							},
							{title: "Skill Administration",isFolder: true,url:'',
							children: [
								{title:'Skill Family Management',url:'./interfaceenginev2.PortalServlet?IID=SkillFamilyManagement' ,isFolder: false},
								{title:'Skill Management',url:'./interfaceenginev2.PortalServlet?IID=SkillManagement' ,isFolder: false},
								{title:'Competency Model',url:'./interfaceenginev2.PortalServlet?IID=CompetencyModel' ,isFolder: false},
								{title:'Competency Level',url:'./interfaceenginev2.PortalServlet?IID=CompetencyLevel' ,isFolder: false},
								{title:'Job Role',url:'./interfaceenginev2.PortalServlet?IID=JobRole' ,isFolder: false},
								{title:'Skill Profile',url:'./interfaceenginev2.PortalServlet?IID=SkillProfile' ,isFolder: false},
								{title:'Profile Details',url:'./interfaceenginev2.PortalServlet?IID=ProfileDetails' ,isFolder: false},
								{title:'Job skill Association',url:'./interfaceenginev2.PortalServlet?IID=JobskillAssociation' ,isFolder: false},
								{title:'Employee Skill Profile',url:'./interfaceenginev2.PortalServlet?IID=EmployeeSkillProfile' ,isFolder: false},
								{title:'Employee Job Role',url:'./interfaceenginev2.PortalServlet?IID=EmployeeJobRole' ,isFolder: false},
								{title:'Employee Career Plan',url:'./interfaceenginev2.PortalServlet?IID=EmployeeCareerPlan' ,isFolder: false},
								{title:'Program Skill Association',url:'./interfaceenginev2.PortalServlet?IID=ProgramSkillAssociation' ,isFolder: false},
								{title:'Help',url:'./interfaceenginev2.PortalServlet?IID=SkillManagementHelp' ,isFolder: false}
							]
							}
							
						]

						}
							
						
				]//main
		});
}

   function f12(dtnode) {
	   document.getElementById('ladminFrame').src = dtnode.data.url;
   }
   function logout_onclick() {
	   ladminTree.sessionInvalidate(function (data){
		   setValue('',data);
	   });
	   //document.LearnityAdminform.target = "_self";
	   window.location= "./interfaceenginev2.PortalServlet?IID=LoginPage";
	   //document.LearnityAdminform.submit() = "";
   }
