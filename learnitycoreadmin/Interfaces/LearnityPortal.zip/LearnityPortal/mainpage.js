$(document).ready(function(){
	
	$("#thesearchstring").css("background-color", "#dadbdb");
	if(document.getElementById("thesearchstring").value==''){
		setValue("thesearchstring","Search...");
	}
	
	$("#thesearchstring").blur(function () {

		search_onblur();
  	//your function  name with bracket  for e.g  delete();
	});
	$("#thesearchstring").focus(function () {

		search_onfocus();
  	//your function  name with bracket  for e.g  delete();
	});
	
	timeshow();
	//onload_click();
	$('#footer-caption a').css('text-decoration','none').css('color','white');
	
});

     function search_onfocus(){
	     $("#thesearchstring").css("background-color", "#ffffff");

	     if(document.getElementById("thesearchstring").value=='Search...')
	     setValue("thesearchstring","");
     }
     
    function search_onblur(){
	     $("#thesearchstring").css("background-color", "#dadbdb");

	     if(document.getElementById("thesearchstring").value=='')
	     setValue("thesearchstring","Search...");
    }
		     
		var vv=1;
		function content_click() {

		};
 
		function admin_click() {

		};
   
		function logout_click() {
			Portal.getUserId(function(data) {
				setValue('logout ',data);
			});
		};
 
		function logout() {
			Portal.setUserIDinvalid(function(data) {
				setValue("message",data);
			});
		};
		function onload_click() {
			unit_onclick();
			linkwebsite()
					dwr.engine.beginBatch();
			Portal.setUserInfo(function(data) {
				setValue('usertable',data);
			});
			Portal.Welcome(function(data) {
				setValue('message',data);
			});
// 			Portal.CheckTimeCompleted(function(data) {
// 				alert(data);
// 				setValue('MainScreen',data);
// 			});
			
			Portal.selfRegistration(function(data) {
				setValue('selfregister',data);
			});
			Portal.getPhoto(function(data) {
				
				setValue('senderImage',data);
			});
			dwr.engine.endBatch();
			loginuser();
		
		};
 
		
 
		function timeshow() {
			var today=new Date();
			var h=today.getHours();
			var m=today.getMinutes();
			var s=today.getSeconds();
			var month=new Array(12);
			month[0]="January";
			month[1]="February";
			month[2]="March";
			month[3]="April";
			month[4]="May";
			month[5]="June";
			month[6]="July";
			month[7]="August";
			month[8]="September";
			month[9]="October";
			month[10]="November";
			month[11]="December";
 	 
			curmonth=month[today.getMonth()];
			year=today.getFullYear();
			day=today.getDate();
 	 
			cdate=curmonth+" "+day+", "+year+" ";
	 
			var str="<br>";
	 
			var time;
	 
			if (h>12)
			{
				h=h-12;
				time=h+ ":" +m+ ":" +s+" p.m";
			}
			else
			{
				time=h+ ":" +m+ ":" +s+" a.m";
			}
 	 
			cdate="<center><font style=\"color:black;font-weight:normal;font-family:verdana,arial;font-size:8pt;\">"
					+cdate+" &nbsp;"+time+"</font></center>";
 
			$('#bottombar3').html(cdate);
			t=setTimeout('timeshow()', 500);
		};
 
  
// 		function lunchCourse(course_id)
// 		{
// 			var browserName = navigator.appName;
// 			var browserVersion = parseInt(navigator.appVersion);
// 			var browser;
// 			if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
// 				browser='ie4up';
// 			}
// 			else {
// 				browser='mf';
// 			}
// 	     							//document.theForm.course_name.value = course_id;
// 	 // document.LearnityPortalform.plugins.value = pluginlist;
// 			document.LearnityPortalform.action='./delivery.LaunchCourse?browser='+browser+'&course_name='+course_id;
// 			window.open('','new','width=750,height=600,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
// 			document.LearnityPortalform.target='new';
// 			document.LearnityPortalform.submit();
// 		}
 
		function lunchCourse(course_id)
		{
			var browserName = navigator.appName;
			var browserVersion = parseInt(navigator.appVersion);
			var browser;
			if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
				browser='ie4up';
			}
			else {
				browser='mf';
			}
	     		// document.theForm.course_name.value = course_id;
	 		// document.LearnityPortalform.plugins.value = pluginlist;
			Portal.lunchCourseAll(browser,browserVersion,course_id,"0","0",function (data) {
				setValue('',data);
			});
			//document.LearnityPortalform.action='./interfaceenginev2.PortalServlet?IID=DeliveryEngine';
			window.open('./interfaceenginev2.PortalServlet?IID=DeliveryEngine','new','fullscreen=yes,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
			//document.LearnityPortalform.target='new';
			//document.LearnityPortalform.submit();
		}
		
		function resume2(course_id ,topic_id,strTopic_Title)
		{
			//alert(course_id);
			//alert(topic_id);
			var browserName = navigator.appName;
			var browserVersion = parseInt(navigator.appVersion);
			var browser;
			if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
				browser='ie4up';
			}
			else {
				browser='mf';
			}
			//window.open('./delivery.LaunchCourse?browser='+browser+'&course_name='+course_id+'&identifier='+topic_id,'new',' width=800,height=600, status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
			Portal.lunchCourseAll(browser,browserVersion,course_id,topic_id,strTopic_Title,function (data) {
				setValue('',data);
			});
			window.open('./interfaceenginev2.PortalServlet?IID=DeliveryEngine','new','fullscreen=yes,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
		}
  
  
  
		/////////////////////////////TABLE   JS/////////////////////////// /////////////////////////////////////////////////////////////////////////////////////////
  
		function ScrollableTable (tableEl, tableHeight, tableWidth) {

			this.initIEengine = function () {

				this.containerEl.style.overflowY = 'auto';
				if (this.tableEl.parentElement.clientHeight - this.tableEl.offsetHeight < 0) {
					this.tableEl.style.width = this.newWidth - this.scrollWidth +'px';
				} else {
					this.containerEl.style.overflowY = 'hidden';
					this.tableEl.style.width = this.newWidth +'px';
				}

				if (this.thead) {
					var trs = this.thead.getElementsByTagName('tr');
					for (x=0; x<trs.length; x++) {
						trs[x].style.position ='relative';
						trs[x].style.setExpression("top",  "this.parentElement.parentElement.parentElement.scrollTop + 'px'");
					}
				}

				if (this.tfoot) {
					var trs = this.tfoot.getElementsByTagName('tr');
					for (x=0; x<trs.length; x++) {
						trs[x].style.position ='relative';
						trs[x].style.setExpression("bottom",  "(this.parentElement.parentElement.offsetHeight - this.parentElement.parentElement.parentElement.clientHeight - this.parentElement.parentElement.parentElement.scrollTop) + 'px'");
					}
				}

				eval("window.attachEvent('onresize', function () { document.getElementById('" + this.tableEl.id + "').style.visibility = 'hidden'; document.getElementById('" + this.tableEl.id + "').style.visibility = 'visible'; } )");
			};


			this.initFFengine = function () {
				this.containerEl.style.overflow = 'hidden';
				this.tableEl.style.width = this.newWidth + 'px';

				var headHeight = (this.thead) ? this.thead.clientHeight : 0;
				var footHeight = (this.tfoot) ? this.tfoot.clientHeight : 0;
				var bodyHeight = this.tbody.clientHeight;
				var trs = this.tbody.getElementsByTagName('tr');
				if (bodyHeight >= (this.newHeight - (headHeight + footHeight))) {
					this.tbody.style.overflow = '-moz-scrollbars-vertical';
					for (x=0; x<trs.length; x++) {
						var tds = trs[x].getElementsByTagName('td');
						tds[tds.length-1].style.paddingRight += this.scrollWidth + 'px';
					}
				} else {
					this.tbody.style.overflow = '-moz-scrollbars-none';
				}

				var cellSpacing = (this.tableEl.offsetHeight - (this.tbody.clientHeight + headHeight + footHeight)) / 4;
				this.tbody.style.height = (this.newHeight - (headHeight + cellSpacing * 2) - (footHeight + cellSpacing * 2)) + 'px';

			};

			this.tableEl = tableEl;
			this.scrollWidth = 16;

			this.originalHeight = this.tableEl.clientHeight;
			this.originalWidth = this.tableEl.clientWidth;

			this.newHeight = parseInt(tableHeight);
			this.newWidth = tableWidth ? parseInt(tableWidth) : this.originalWidth;

			this.tableEl.style.height = 'auto';
			this.tableEl.removeAttribute('height');

			this.containerEl = this.tableEl.parentNode.insertBefore(document.createElement('div'), this.tableEl);
			this.containerEl.appendChild(this.tableEl);
			this.containerEl.style.height = this.newHeight + 'px';
			this.containerEl.style.width = this.newWidth + 'px';


			var thead = this.tableEl.getElementsByTagName('thead');
			this.thead = (thead[0]) ? thead[0] : null;

			var tfoot = this.tableEl.getElementsByTagName('tfoot');
			this.tfoot = (tfoot[0]) ? tfoot[0] : null;

			var tbody = this.tableEl.getElementsByTagName('tbody');
			this.tbody = (tbody[0]) ? tbody[0] : null;

			if (!this.tbody) return;

			if (document.all && document.getElementById && !window.opera) this.initIEengine();
			if (!document.all && document.getElementById && !window.opera) this.initFFengine();


		}
  
  
		/////////////////////////////TABLE   JS//////////////////////////////////////////////////////////////////////////////////////////
  
  
		function selfRegistration_onClick()
		{
			//document.LearnityPortalform.method ='post';
			//document.LearnityPortalform.action='./PortalMgmt.portal.selfRegistration';
			window.open('./PortalMgmt.portal.selfRegistration','selfregistration','width=610,height=500,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
			//document.LearnityPortalform.target='selfregistration';
			//document.LearnityPortalform.submit();
		}
		function loginuser() {
			Portal.UserLoginNo(function(data) {
				setValue('bottombar1',data);
				   
			});
			
			   //var int=self.setInterval("loginuser()",60000);      
		}
		
// 		function basic_search() {
// 			var n = document.LearnityPortalform.thesearchstring.value;
// 			window.open('./PortalMgmt.portal.BasicSearchTheUnit?thesearchstring='+n,'basic','width=800,height=600,status=yes,resizeable=yes,toolbar=no,location=no');
		//
// 		}
		function basic_search() {
// 			var n = document.LearnityPortalform.thesearchstring.value;
			var n =getValue('thesearchstring');
			//alert(n);
			/*
			Portal.setSearchString(n,function(data) {
			window.open('./interfaceenginev2.PortalServlet?IID=BasicSearch','basic','width=800,height=600,status=yes,resizeable=yes,toolbar=no,location=no');

		});*/
			window.open('./learnityinterfaceportal.BasicSearchTheUnit?thesearchstring='+n,'basic','width=800,height=600,status=yes,resizeable=yes,toolbar=no,location=no');
				
		}

// 	NS4 = (document.layers) ? true : false;
// 	function checkEnter(event)	
// 	{ 
// 		var code = 0;
// 		if (NS4)  		
// 		code = event.which; 	
// 		else  		
// 			code = event.keyCode;	
// 		if (code==13) 		
// 		basic_search();
// 	}	;
// 		function unit_click(){
// 			Portal.LoObjectGrid(function(data) {
// 				setValue('mainsub',data);
// 			});
// 		}
		/** CHANGES BY ANINDYA*/
// 		function forum_onclick(){
// 			Portal.forumGrid(function(data) {
// 				setValue('mainsub',data);
// 			});
// 		}
	
		function forum(strforum,strfname)
		{
			launchforum(strforum);
			Portal.setForumId(strforum,function(data) {
				setValue('forummainscreen',data);
			});
		 
		}
	 
		function launchforum(strforum)
		{
		
		
			Portal.setForumId(strforum);
			//document.LearnityPortalform.method ="post";
						
			//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=forum";
			window.open('./interfaceenginev2.PortalServlet?IID=forum',"forum","width=900,height=670,status=yes,scrollbars=no,resizable=yes,toolbar=no,menubar=no");
			//document.LearnityPortalform.target="forum";
			//document.LearnityPortalform.submit();
		}
	/*function forum(strforum,strfname)
		{
		
		var browserName = navigator.appName;
		var browserVersion = parseInt(navigator.appVersion);
		var browser;
		if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
		browser='ie4up';
}
		else {
		browser='mf';
}
		//alert("strforum");
		//alert("strfname");
		var n = strforum;
		var n1 = strfname;
		document.LearnityPortalform.method ="post";
		/////document.LearnityPortalform.action="./forum.discussionforum.DiscussionForum?select_type=2&thread_id=1&replyId=1&strforum="+n+"&strfname="+n1;       				
		document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=forum";
		window.open("","forum","width=900,height=670,status=yes,scrollbars=no,resizable=yes,toolbar=no,menubar=no");
		document.LearnityPortalform.target="forum";
		document.LearnityPortalform.submit();
}*/
		/** END ANINDYA */
	 
		////////////////////////////   Changes By Indra   //////////////////////////////////////
	 
		
// 		function course_onclick(collection_id){
// 			Portal.courseGrid(collection_id,function(data) {
// 				setValue('mainsub',data);
// 			});
// 		}
	 
	
		function launchCoursemanagement(course_id,course_name,topic_id)
		{
			lauchCMS(course_id,course_name);
			var topic_id="Home";
			Portal.setSessioncourseId(course_id,topic_id,function(data) {
				setValue('CourseHome',data);
			});
		}
	 
		function lauchCMS(course_id,course_name)
		{
			var browserName = navigator.appName;
			var browserVersion = parseInt(navigator.appVersion);
			var browser;
			if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
				browser='ie4up';
			}
			else {
				browser='mf';
			}
	  
			//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=Course";    				
			window.open('./interfaceenginev2.PortalServlet?IID=Course','Course','width=850,height=690,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
			//document.LearnityPortalform.target='Course';
			//document.LearnityPortalform.submit();
		}
	
	  
		function launchCoursemanagementBookmark(course_id,course_name,topic_id)
		{
			lauchCMSBookmark(course_id,course_name,topic_id);
			Portal.setSessioncourseIdBookmark(course_id,topic_id,function(data) {
				setValue('',data);
			});
		}
	 	     		
 
		function lauchCMSBookmark(course_id ,course_name,topic_id)
		{
			var browserName = navigator.appName;
			var browserVersion = parseInt(navigator.appVersion);
			var browser;
			if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
				browser='ie4up';
			}
			else {
				browser='mf';
			}
			//document.LearnityPortalform.method ='post';
			//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=Course";    				
			window.open('./interfaceenginev2.PortalServlet?IID=Course','Course',' width=850,height=690, status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
			//document.LearnityPortalform.target='Course';
			//document.LearnityPortalform.submit();
		}
		//////////////////////////  Changes by Indra ---- End  /////////////////////////////
    
	
		function linkwebsite(){
			var t=document.getElementById('bottombar2');
			t.innerHTML='<a href=\'http://www.aunwesha.com\' target=\'new\'>Powered By LearnITY</a><sup>TM</sup>';
		}
		/************************* Appended By Kunal On 03.10.2008 *************************/
// 		function sce_onclick(){
// 			Portal.getSceGrid(function(data) {
// 				setValue('mainsub',data);
// 			});
// 		}
		function chatLunch(id,sessionid) {

			var browserName = navigator.appName;
			var browserVersion = parseInt(navigator.appVersion);
			var browser;
			if(browserName == "Microsoft Internet Explorer" && browserVersion >= 4) {
				browser = "ie4up";
			} else {
				browser = "mf";
			}
			
			Portal.setSessionSceId(id,browser,function(data) {
				
			});
			
			//document.LearnityPortalform.method = "post";
			/*document.LearnityPortalform.action= "./sc.sce.SceAdministration?ID="+id+"&browser="+browser+"&Session="+sessionid;*/
			//document.LearnityPortalform.action= "./interfaceenginev2.PortalServlet?IID=SCE";
			window.open('./interfaceenginev2.PortalServlet?IID=SCE','chatgroup','width="100%",height="100%",status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no');
			//document.LearnityPortalform.target = "chatgroup";
			//document.LearnityPortalform.submit();
		}
		function chatLunchRecorded(id,rsession) {

			//document.LearnityPortalform.method = "post";
// 		document.LearnityPortalform.action = "./sc.sce.SCEOffline?ID="+id+"&Session="+rsession;
			//document.LearnityPortalform.action= "./interfaceenginev2.PortalServlet?IID=SCE";
			window.open('./interfaceenginev2.PortalServlet?IID=SCE',"chatgroup","width=100%,height=100%,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
			//document.LearnityPortalform.target = "chatgroup";
			//document.LearnityPortalform.submit();
		}
		/************************* End Kunal On 03.10.2008 *************************/
	
		// ////////////////////////////// Changes Made by Aurobroto ////////////////////////////////////
	
		function loadnotebook()
		{
			//document.LearnityPortalform.method ="post";
			//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=NoteBook";
			window.open('./interfaceenginev2.PortalServlet?IID=NoteBook',"notebook","width=800,height=600,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
			//document.LearnityPortalform.target="notebook";
			//document.LearnityPortalform.submit();
		}
		// ////////////////////////////// Changes Made by Aurobroto ////////////////////////////////////

		/*====================Nayna start=======================*/
		
		function assessment(){
			Portal.AssessmentGrid(function(data) {
				setValue('mainsub',data);
			});
		}
	
		function check_onclick(){
			var asessmentid=getValue("checkbox");
			Portal.setCounter(asessmentid);
					
		}
	
	
		function loadassessment()
		{
			//document.LearnityPortalform.method ="post";
			//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=LearnityAsmtPortal";
			window.open('./interfaceenginev2.PortalServlet?IID=LearnityAsmtPortal',"assessment","width=800,height=700,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
			//document.LearnityPortalform.target="assessment";                    
			//document.LearnityPortalform.submit();
		}
	
	
		function start_onclick(){
			var asessmentid=getValue("checkbox");
			Portal.asmtAvailablityCheck(asessmentid,sttest1);
	
	
		}
		function sttest1(data) {
			var asessmentid=getValue("checkbox");
	 
			var timeavailable = "";
			var avail1 = "";
			var valid1 = "";
			var MaxtestTeken = "";
			var nooftimesappeared = "";
			var message = "";
			timeavailable=data[1];
			avail1=data[2];
			valid1=data[3];
			MaxtestTeken=data[4];
			nooftimesappeared=data[5];
			message=data[6];
			if(asessmentid!=false) {
				if((MaxtestTeken!="") && (Number(MaxtestTeken)>Number(nooftimesappeared)))
				{
					if(valid1 == "Available"){
						if((avail1 == "Available") && (timeavailable == "Available"))
						{
							loadassessment();
			
						}
						else{
							alert("Selected Assessment is not available");
						}
					}
					else {
						alert("Validity finished");
					}
				}
				else {
					alert("message");
				}
			}
			else {
				alert("Please Select a Assessment");
			}
		}
	
		
		
		/*=====================Nayna end=======================*/

		/** CHANGES BY ANINDYA / Surajit */
// 		function forum_onclick(){
// 			Portal.forumGrid(function(data) {
// 				setValue('mainsub',data);
// 			});
// 		}
		function forum(strforum,strfname)
		{
			launchforum(strforum);
			Portal.setForumId(strforum,function(data) {
				setValue('forummainscreen',data);
			});
		 
		}
	
		function launchforum(strforum)
		{
		
		
			Portal.setForumId(strforum);
			//	document.LearnityPortalform.method ="post";
						
				//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=forum";
			window.open('./interfaceenginev2.PortalServlet?IID=forum',"forum","width=900,height=670,status=yes,scrollbars=no,resizable=yes,toolbar=no,menubar=no");
				//document.LearnityPortalform.target="forum";
				//document.LearnityPortalform.submit();
		}
		/** END ANINDYA / Surajit */
			
			
			
		/////////////////////////  jayanta /////////////////////////////////
// 		function notice_onclick() {
// 	 
// 			NoticePOJO.getNotice(function(data) {
// 				setValue('mainsub',data);
// 			});
// 			var t = new ScrollableTable(document.getElementById('myScrollTable'), 250,200);
// 		}
 
 
		function lunchNotice(strnotice_id)
		{
				
			NoticePOJO.setSessionNoticeId(strnotice_id,function(data) {
				//	setValue('CourseHome',data);
				alert(strnotice_id);
			});
		 	 
	 
	 
			var browserName = navigator.appName;
			var browserVersion = parseInt(navigator.appVersion);
			var browser;
			if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
				browser='ie4up';
			}
			else {
				browser='mf';
			}
				
	 
	
	 
		
			var n = strnotice_id;
				
				//document.LearnityPortalform.method ="post";
		       				
				//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=LearnityNoticeBoardview";
		
			window.open('./interfaceenginev2.PortalServlet?IID=LearnityNoticeBoardview',"LearnityNoticeBoardview","width=600,height=540,status=yes,scrollbars=no,resizable=yes,toolbar=no,menubar=no");
				//document.LearnityPortalform.target="LearnityNoticeBoardview";                    
				//document.LearnityPortalform.submit();  
	 
				//document.LearnityPortalform.method ="post";
		}
 
 
 
		function AddNewNotice()
		{
				
			var browserName = navigator.appName;
			var browserVersion = parseInt(navigator.appVersion);
			var browser;
			if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
				browser='ie4up';
			}
			else {
				browser='mf';
			}
 
				//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=LearnityNoticeBoard";
			window.open('./interfaceenginev2.PortalServlet?IID=LearnityNoticeBoard',"LearnityNoticeBoard","width=600,height=540,status=yes,scrollbars=no,resizable=yes,toolbar=no,menubar=no");
				//document.LearnityPortalform.target="LearnityNoticeBoard";                    
				//document.LearnityPortalform.submit();  
		}
 
		// ////////////////////////////// Changes Made by Jayanta after 08/01/09 ////////////////////////////////////
	
		function loadCatalog()
		{
			//document.LearnityPortalform.method ="post";
			//document.LearnityPortalform.action="./interfaceenginev2.PortalServlet?IID=NoteBook";
			window.open('./interfaceenginev2.PortalServlet?IID=CatalogPortal',"CatalogPortal","width=800,height=600,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
			//document.LearnityPortalform.target="notebook";
			//document.LearnityPortalform.submit();
		}
		function loadPasswordChange()
		{
 			window.open('./interfaceenginev2.PortalServlet?IID=ChangePassword',"ChangePassword","width=800,height=600,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
		}
		function change_profile()
		{
			window.open('./interfaceenginev2.PortalServlet?IID=ChangeProfile',"ChangeProfile","width=800,height=600,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
		}
		// ////////////////////////////// End Changes Made by Jayanta after 08/01/09 ////////////////////////////////////

			///////////////////////// end jayanta /////////////////////////////////////////////x
			
		function calender_onclick()
		{
			window.open("./calendar.calendar.CalendarMain","Calendar","width=800,height=600,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
		
		}
		function training_onclick(){
			window.open('./interfaceenginev2.PortalServlet?IID=TrainingLink',"Traininglink","width=750,height=500,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
		}
			
		function load_help()
		{
			
			window.open('../html/LearnITyHelp_for_Login_Courses.html',"help","width=800,height=600,status=yes,scrollbars=yes,resizable=yes,toolbar=no,menubar=no");
			
		}
			function unit_onclick()
			{
				resetTabColor();
				/*$("#tabcourselink").css("background-color", "#8BE5FB");
				$("#tabassessmentlink").css("background-color", "#8BE5FB");
				$("#tabforumlink").css("background-color", "#8BE5FB");
				$("#tabscelink").css("background-color", "#8BE5FB");
				$("#tabnoticelink").css("background-color", "#8BE5FB");
				$("#tabunitlink").css("background-color", "#6398ff");*/
				
				$("#tabunitlink").css("background-color", "#e0e0e0");
				$("#tabunitlink").focus();
				$("#tabunitlink").css("border", "1px solid #ccc");
				PortalEngine.getInterfaceFragment("LearnityPortal","PortalUnit",setFragUnit);
			}
			function setFragUnit(vstring)
			{
				setFragment("mainsub",vstring);
				showdata();
			}
			function showdata()
			{
				Portal.getUnits(setUnitData);

			}

			function setUnitData(data)
			{
				setArrayGridRowData("PortalUnit_UnitGrid",data);
				page_load();
			}
			
			function course_onclick(){
				resetTabColor();
				/*$("#tabunitlink").css("background-color", "#8BE5FB");
				$("#tabassessmentlink").css("background-color", "#8BE5FB");
				$("#tabforumlink").css("background-color", "#8BE5FB");
				$("#tabscelink").css("background-color", "#8BE5FB");
				$("#tabnoticelink").css("background-color", "#8BE5FB");
				$("#tabcourselink").css("background-color", "#6398ff");*/
				
				$("#tabcourselink").css("background-color", "#e0e0e0");
				$("#tabcourselink").focus();
				$("#tabcourselink").css("border", "1px solid #ccc");
				PortalEngine.getInterfaceFragment("LearnityPortal","PortalCourseGrid",setFragCourse);
			}
			function setFragCourse(vstring)
			{
				setFragment("mainsub",vstring);
				Portal.getUserRole(course_page_load);
				
			}
			function course_page_load(data){
				if(data=="TEACHER"){
					body_onlad();
				}
				else if(data=="STUDENT"){
					student_body_onlad();
				}
			}

			function assessment_onclick(){
				resetTabColor();
				/*$("#tabcourselink").css("background-color", "#8BE5FB");
				$("#tabforumlink").css("background-color", "#8BE5FB");
				$("#tabscelink").css("background-color", "#8BE5FB");
				$("#tabnoticelink").css("background-color", "#8BE5FB");
				$("#tabunitlink").css("background-color", "#8BE5FB");
				$("#tabassessmentlink").css("background-color", "#6398ff");*/
				
				$("#tabassessmentlink").css("background-color", "#e0e0e0");
				$("#tabassessmentlink").focus();
				$("#tabassessmentlink").css("border", "1px solid #ccc");
				PortalEngine.getInterfaceFragment("LearnityPortal","PortalAssGrid",setFragAssessment);
			}
			function setFragAssessment(vstring)
			{
				setFragment("mainsub",vstring);
 				showAssdata();
			}
			function showAssdata()
			{
				Portal.AssessmentGrid(setAssessmentData);

			}

			function setAssessmentData(data)
			{
				setArrayGridRowData("PortalAssGrid_portalgrid",data);
			}

			
			function forum_onclick(){
				resetTabColor();
				//$("#tabcourselink").css("background-color", "#8BE5FB");
				//$("#tabassessmentlink").css("background-color", "#8BE5FB");
				//$("#tabscelink").css("background-color", "#8BE5FB");
				//$("#tabnoticelink").css("background-color", "#8BE5FB");
				//$("#tabunitlink").css("background-color", "#8BE5FB");
				//$("#tabforumlink").css("background-color", "#6398ff");
				$("#tabforumlink").css("background-color", "#e0e0e0");
				$("#tabforumlink").focus();
				$("#tabforumlink").css("border", "1px solid #ccc");
				PortalEngine.getInterfaceFragment("LearnityPortal","PortalForumGrid",setFragForum);
			}
			function setFragForum(vstring)
			{
				setFragment("mainsub",vstring);
				showForum();
			}
			function showForum()
			{
				Portal.forumGrid(setForumData);

			}

			function setForumData(data)
			{
				setArrayGridRowData("PortalForumGrid_portalgrid",data);
				forum_load();
			}


			function sce_onclick(){
				resetTabColor();
				//$("#tabcourselink").css("background-color", "#8BE5FB");
				//$("#tabassessmentlink").css("background-color","#8BE5FB");
				//$("#tabforumlink").css("background-color", "#8BE5FB");
				//$("#tabnoticelink").css("background-color", "#8BE5FB");
				//$("#tabunitlink").css("background-color", "#8BE5FB");
				$("#tabscelink").css("background-color", "#e0e0e0");
				$("#tabscelink").focus();
				$("#tabscelink").css("border", "1px solid #ccc");
				PortalEngine.getInterfaceFragment("LearnityPortal","PortalSceGrid",setFragSce);
			}
			function setFragSce(vstring)
			{
				setFragment("mainsub",vstring);
 				showSCE();
			}
			function showSCE()
			{
				Portal.getSceGrid(setSceData);

			}

			function setSceData(data)
			{
				setArrayGridRowData("PortalSceGrid_portalgrid",data);
			}

			function notice_onclick(){
				resetTabColor();
				/*$("#tabunitlink").css("background-color", "#8BE5FB");
				$("#tabcourselink").css("background-color", "#8BE5FB");
				$("#tabassessmentlink").css("background-color", "#8BE5FB");
				$("#tabforumlink").css("background-color", "#8BE5FB");
				$("#tabscelink").css("background-color", "#8BE5FB");
				$("#tabcourselink").css("background-color", "#8BE5FB");*/
				$("#tabnoticelink").css("background-color", "#e0e0e0");
				$("#tabnoticelink").focus();
				$("#tabnoticelink").css("border", "1px solid #ccc");
//				/$("#tabnoticelink").css("background-color", "#6398ff");
				PortalEngine.getInterfaceFragment("LearnityPortal","PortalNoticeGrid",setFragNotice);
			}
			function setFragNotice(vstring)
			{
				setFragment("mainsub",vstring);
				showNotice();
			}
			function showNotice()
			{
				NoticePOJO.getNotice(setNoticeData);

			}

			function setNoticeData(data)
			{
				setArrayGridRowData("PortalNoticeGrid_portalgrid",data);
			}
			
			function resetTabColor(){
				$("#tabcourselink").css("background-color", "transparent");
				$("#tabassessmentlink").css("background-color", "transparent");
				$("#tabforumlink").css("background-color", "transparent");
				$("#tabscelink").css("background-color", "transparent");
				$("#tabnoticelink").css("background-color", "transparent");
				$("#tabunitlink").css("background-color", "transparent");
				
				$("#tabcourselink").css("border", "none");
				$("#tabassessmentlink").css("border", "none");
				$("#tabforumlink").css("border", "none");
				$("#tabscelink").css("border", "none");
				$("#tabnoticelink").css("border", "none");
				$("#tabunitlink").css("border", "none");
			} 

			