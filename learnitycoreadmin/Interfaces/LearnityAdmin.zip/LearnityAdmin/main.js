function onload_click() {
			$("#ladminTree").dynatree({
				title: "Sample",
				autoCollapse: 'true',
				keyboard: 'true',
				onActivate: function(dtnode) {
					$("#ladminTitle").text(dtnode.data.title);
					f12(dtnode);
					},
					children: [
					{title: "Course Management",isFolder: true,url:'',
							children: [
							{title: "Course Administration",isFolder: true,url:'',
								children: [
									{title:'Definition',url:'./interfaceenginev2.PortalServlet?IID=CourseDefAdmin' ,isFolder: false},
									{title:'Schedule',url:'./interfaceenginev2.PortalServlet?IID=CourseScheduleAdmin' ,isFolder: false},
									{title:'Syllabus',url:'./interfaceenginev2.PortalServlet?IID=CourseSyllabusAdmin' ,isFolder: false},
									{title:'Resource',url:'./interfaceenginev2.PortalServlet?IID=CourseResourceAdmin' ,isFolder: false},
									{title:'Announcements',url:'./interfaceenginev2.PortalServlet?IID=CourseAnnouncementAdmin' ,isFolder: false},
									{title:'Course Collection Management',url:'./interfaceenginev2.PortalServlet?IID=CourseCollectionMgmtAdmin' ,isFolder: false},
									{title:'Course Collection Association',url:'./interfaceenginev2.PortalServlet?IID=CourseCollectionAssoAdmin' ,isFolder: false},
									{title:'Department Course Association',url:'./interfaceenginev2.PortalServlet?IID=DeptCourseAssoAdmin' ,isFolder: false},
									{title:'User Course Registration',url:'./interfaceenginev2.PortalServlet?IID=CourseUserRegAdmin' ,isFolder: false},
									{title:'Group Registration Administration',url:'./interfaceenginev2.PortalServlet?IID=CourseGroupRegAdmin' ,isFolder: false},
									{title:'Help',url:'../servlets/CourseManagementHelp.html' ,isFolder: false}
								]
								},
								{title: "Instructor Administration",isFolder: true,url:'',
								children: [
									{title:'Instructor Definition',url:'./interfaceenginev2.PortalServlet?IID=CourseInstructorAdmin' ,isFolder: false}
								]
								},
								{title: "Session Administration",isFolder: true,url:'',
								children: [
									{title:'Session Definition',url:'./interfaceenginev2.PortalServlet?IID=CourseSessionAdmin' ,isFolder: false}
								]
								},
								{title: "Location Administration",isFolder: true,url:'',
								children: [
									{title:'Definition',url:'./interfaceenginev2.PortalServlet?IID=CourseLocationAdmin' ,isFolder: false}
								]
								},
								{title: "Gradebook Administration",isFolder: true,url:'',
								children: [
									{title:'Grading Category Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradCatMgmtAdmin' ,isFolder: false},
									{title:'Grading Scale Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeScaleMgmtAdmin' ,isFolder: false},
									{title:'Grading Item Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeItemMgmt' ,isFolder: false},
									{title:'Grade Book Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeBookMgmtAdmin' ,isFolder: false},
									{title:'Grade Book Item Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeBookItemMgmt' ,isFolder: false},
									{title:'Grade Book Course Association',url:'./interfaceenginev2.PortalServlet?IID=CourseBookCourseAssoAdmin' ,isFolder: false}
								]
								},
								{title: "Assignment Administration",isFolder: true,url:'',
								children: [
									{title:'Assignment Management',url:'./interfaceenginev2.PortalServlet?IID=CourseAssignMgmtAdmin' ,isFolder: false},
									{title:'Assignment Document Management',url:'./interfaceenginev2.PortalServlet?IID=CourseAssignDocMgmt' ,isFolder: false},
									{title:'Assignment Course Association',url:'./interfaceenginev2.PortalServlet?IID=CourseAssgnCourseAssoAdmin' ,isFolder: false},
									{title:'Assignment Feedback Management',url:'./interfaceenginev2.PortalServlet?IID=CourseAssignmentFeedbackManagement' ,isFolder: false}
								]
								}	
							]
						}
				]//main
		});
}

   function f12(dtnode) {
	   document.getElementById('ladminFrame').src = dtnode.data.url;
   }
   function logout_onclick() {
	   ladminTree.sessionInvalidate(function (data){
		   setValue('',data);
	   });
	   //document.LearnityAdminform.target = "_self";
	   window.location= "./interfaceenginev2.PortalServlet?IID=LoginPage";
	   //document.LearnityAdminform.submit() = "";
   }
