
//alert(dtnode.data.url);
var url1=dtnode.data.url;
// alert(url1);
var length1=url1.length;
//alert(length1);
var s1=url1.substring(length1-4,length1);
/*
var filename1=url1.substring(url1.lastindexof('/')+1, length1); 
alert("filename1==="+filename1);
var filename2=url1.substring(url1.indexof('//')+1, length1); 
alert("filename2==="+filename2);*/
var browserName = navigator.appName;
var browserVersion = parseInt(navigator.appVersion);
//var b="";
if(s1!='asmt'){
	launchcourse.setSessionSequence(dtnode.data.sequence,function(data){});
// 	alert(dtnode.data.url);
	document.getElementById("deliveryIframe").src = dtnode.data.url;
	$("#nodeKey").val(dtnode.data.key);
	launchcourse.onselectTitle(dtnode.data.key,dtnode.data.tooltip,function(data) {
		var b=data;
		//alert("..."+b);
	
		if(b=='true')
		{
			location.href="./interfaceenginev2.PortalServlet?IID=LoginPage";
		}
	});	
}
else{
	launchcourse.setSessionSequence(dtnode.data.sequence,function(data){});
	document.getElementById("deliveryIframe").src = dtnode.data.url;
	$("#nodeKey").val(dtnode.data.key);
	//var filename1="";
	launchcourse.onselectTitle(dtnode.data.key,dtnode.data.tooltip,function(data) {
		var b=data;
		//alert("..."+b);
	
		if(b=='true')
		{
			location.href="./interfaceenginev2.PortalServlet?IID=LoginPage";
		}
	});	
	launchcourse.getEmbeddedAssessment(dtnode.data.url,function(data){
		var filename1=data[0];
		var cid=data[1];
		//alert("filename1===="+filename1);
		//alert("cid============"+cid);
		if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
			document.getElementById("deliveryIframe").src =  "./learnityasmtserver.assessmentportal.embeddedasmt.Assessment?s="+filename1+"&cid="+cid+"&identifier="+dtnode.data.key;
		}
		else {
			document.getElementById("deliveryIframe").src =  "./learnityasmtserver.assessmentportal.embeddedasmt.AssessmentXHTML?s="+filename1+"&cid="+cid+"&identifier="+dtnode.data.key;
		}
	});
	

}