function onload_click() {
			$("#ladminTree").dynatree({
				title: "Sample",
				autoCollapse: 'true',
				keyboard: 'true',
				onActivate: function(dtnode) {
					$("#ladminTitle").text(dtnode.data.title);
					f12(dtnode);
					},
					children: [
					{title: "User",isFolder: true,url:'',
						children: [
						{title: "User Administration",isFolder: true,url:'',
							children: [
								{title:'User Account Administration',url:'./interfaceenginev2.PortalServlet?IID=UserCreation' ,isFolder: false},
							        {title:'User Role Association',url:'./interfaceenginev2.PortalServlet?IID=UserRoleAssociation' ,isFolder: false},
							        {title:'Change Profile',url:'./interfaceenginev2.PortalServlet?IID=ChangeProfile' ,isFolder: false},
								{title:'Change Password',url:'./interfaceenginev2.PortalServlet?IID=ChangePassword' ,isFolder: false},
								{title:'User Chart',url:'./interfaceenginev2.PortalServlet?IID=userChart' ,isFolder: false}

							]
							},
							{title: "Group Administration",isFolder: true,url:'',
							children: [
								{title:'Create Group',url:'./interfaceenginev2.PortalServlet?IID=UserGroupAdmin' ,isFolder: false},
								//{title:'User Registration Administration',url:'./interfaceenginev2.PortalServlet?IID=UserRegAdmin' ,isFolder: false},
								{title:'Group User Registration',url:'./interfaceenginev2.PortalServlet?IID=GroupUserReg' ,isFolder: false}
								//{title:'Group Registration Administration',url:'./interfaceenginev2.PortalServlet?IID=GroupRegAdmin' ,isFolder: false},

							]
							},
							{title: "Access Administration",isFolder: true,url:'',
							children: [
								{title:'User Access Management',url:'./interfaceenginev2.PortalServlet?IID=UserAccessMgmt' ,isFolder: false},
								{title:'Group Access Management',url:'./interfaceenginev2.PortalServlet?IID=GroupAccessMgmt' ,isFolder: false}
							]
							},
							{title: "View Dynamic Information",isFolder: true,url:'',
							children: [
								{title:'View Dynamic Information',url:'./interfaceenginev2.PortalServlet?IID=DynaInfoBy' ,isFolder: false}
								//{title:'View Dynamic Information by User',url:'./interfaceenginev2.PortalServlet?IID=DynaInfoByUser' ,isFolder: false}
// 								{title:'View Dynamic Information by Unit',url:'./interfaceenginev2.PortalServlet?IID=DynaInfoByUnit' ,isFolder: false}
							]
							},
							{title: "View Report",isFolder: true,url:'',
							children: [
							{title:'View User Report',url:'./interfaceenginev2.PortalServlet?IID=userReport' ,isFolder: false},
							{title:'View User Chart',url:'./interfaceenginev2.PortalServlet?IID=UserChart' ,isFolder: false}
							//{title:'Application Usage Report',url:'./interfaceenginev2.PortalServlet?IID=ApplicationUsageReport' ,isFolder: false}
							]
							}
						]
						},
						{title:'Content Management',isFolder: true,url:'',
						children: [
						{title: "Unit Administration",isFolder: true,url:'',
							children: [
								{title:'Manage Units',url:'./interfaceenginev2.PortalServlet?IID=ManageUnitAdmin' ,isFolder: false},
								{title:'Manage Unit Registration By User',url:'./interfaceenginev2.PortalServlet?IID=UnitRegByUser' ,isFolder: false},
								{title:'Manage Unit Registration By Group',url:'./interfaceenginev2.PortalServlet?IID=UnitRegByGroup' ,isFolder: false},
								{title:'Unit Registration Confirmation',url:'./interfaceenginev2.PortalServlet?IID=UnitRegistrationConfirmation' ,isFolder: false},
								{title:'Populau Unit Chart',url:'./interfaceenginev2.PortalServlet?IID=popularunit' ,isFolder: false}
								//{title:'DashboardUnits',url:'../servlet/dashboard.chart3?id=popularunit' ,isFolder: false},
								//{title:'SCORM Initialization',url:'./interfaceenginev2.PortalServlet?IID=SCORMInitialization' ,isFolder: false},
								//{title:'Unit Prerequisite Management',url:'./interfaceenginev2.PortalServlet?IID=UnitPrerequisiteMgmt' ,isFolder: false},
								//{title:'Unit Completion Management',url:'./interfaceenginev2.PortalServlet?IID=UnitCompletionMgmt' ,isFolder: false},
								
							]
							},
							{title:'Repository Administration',isFolder: true,url:'',
							children: [
								{title:'Manage Unit Information',url:'./interfaceenginev2.PortalServlet?IID=ManageUnitInformation'},
								{title:'Manage Unit Home Page',url:'./interfaceenginev2.PortalServlet?IID=ManageUnitHomePage'},
								//{title:'Manage Content Objects',url:'./interfaceenginev2.PortalServlet?IID=ManageContentObjects'},
								{title:'Unit Import and Export',url:'./interfaceenginev2.PortalServlet?IID=unitImportExport'}		
							]
							},
							/*{title:'Qualifier Administration',isFolder: true,
							children: [
								{title:'Manage Qualifiers',url:'./interfaceenginev2.PortalServlet?IID=ManageQualifiers'}
							]
							},*/
							{title:'Qualifier Administration',isFolder: true,url:'',
							children: [
							{title:'Manage Qualifiers',url:'./interfaceenginev2.PortalServlet?IID=ManageQualifiers'}
							]
							},
							{title: "View Report",isFolder: true,url:'',
							children: [
							//{title:'View Unit Report',url:'./interfaceenginev2.PortalServlet?IID=unitReport' ,isFolder: false}
							{title:'Unit completion Report',url:'./interfaceenginev2.PortalServlet?IID=UnitCompletionReport' ,isFolder: false}
							
							]
							}
						]
						},
						{title: "Course Management",isFolder: true,url:'',
						children: [
						{title: "Course Administration",isFolder: true,url:'',
							children: [
								{title:'Definition',url:'./interfaceenginev2.PortalServlet?IID=CourseDefAdmin' ,isFolder: false},
								{title:'Schedule',url:'./interfaceenginev2.PortalServlet?IID=CourseScheduleAdmin' ,isFolder: false},
								{title:'Syllabus',url:'./interfaceenginev2.PortalServlet?IID=CourseSyllabusAdmin' ,isFolder: false},
								{title:'Resource',url:'./interfaceenginev2.PortalServlet?IID=CourseResourceAdmin' ,isFolder: false},
								{title:'Course Registration Confirmation',url:'./interfaceenginev2.PortalServlet?IID=CourseRegistrationConfirmation' ,isFolder: false},
								{title:'Announcements',url:'./interfaceenginev2.PortalServlet?IID=CourseAnnouncementAdmin' ,isFolder: false},
								{title:'Course Collection Management',url:'./interfaceenginev2.PortalServlet?IID=CourseCollectionMgmtAdmin' ,isFolder: false},
								{title:'Course Collection Association',url:'./interfaceenginev2.PortalServlet?IID=CourseCollectionAssoAdmin' ,isFolder: false},
								{title:'Course Instructor Association',url:'./interfaceenginev2.PortalServlet?IID=CourseInstrAsso' ,isFolder: false},
								{title:'Course User Registration',url:'./interfaceenginev2.PortalServlet?IID=CourseUserRegAdmin' ,isFolder: false},
								{title:'Course Group Registration',url:'./interfaceenginev2.PortalServlet?IID=CourseGroupRegAdmin' ,isFolder: false},
								{title:'Course Usage Report',url:'./interfaceenginev2.PortalServlet?IID=CourseUsageReport' ,isFolder: false},
								{title:'Popular Course Chart',url:'./interfaceenginev2.PortalServlet?IID=popularcourse' ,isFolder: false},
								{title:'Help',url:'../html/CourseManagementHelp.html' ,isFolder: false}
							]
							},
							{title: "Instructor Administration",isFolder: true,url:'',
							children: [								
								{title:'Instructor Role Association',url:'./interfaceenginev2.PortalServlet?IID=InstrRoleAsso' ,isFolder: false}
							]
							},
							{title: "Session Administration",isFolder: true,url:'',
							children: [
								{title:'Session Definition',url:'./interfaceenginev2.PortalServlet?IID=CourseSessionAdmin' ,isFolder: false}
							]
							},
							{title: "Location Administration",isFolder: true,url:'',
							children: [
								{title:'Definition',url:'./interfaceenginev2.PortalServlet?IID=CourseLocationAdmin' ,isFolder: false}
							]
							},
							{title: "Gradebook Administration",isFolder: true,url:'',
							children: [
								{title:'Grading Category Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradCatMgmtAdmin' ,isFolder: false},
								{title:'Grading Scale Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeScaleMgmtAdmin' ,isFolder: false},
								{title:'Grading Scale Scheme Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeScaleSchemeAdmin' ,isFolder: false},
								{title:'Grading Item Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeItemMgmt' ,isFolder: false},
								{title:'Grade Book Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeBookMgmtAdmin' ,isFolder: false},
								{title:'Grade Book Item Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeBookItemMgmt' ,isFolder: false},
								{title:'Grade Book Course Association',url:'./interfaceenginev2.PortalServlet?IID=CourseBookCourseAssoAdmin' ,isFolder: false},
								{title:'Grade Management',url:'./interfaceenginev2.PortalServlet?IID=CourseGradeMgmt' ,isFolder: false},
								{title:'Grade View Management',url:'./interfaceenginev2.PortalServlet?IID=GradeViewMgmt' ,isFolder: false},
								{title:'View Grade',url:'./interfaceenginev2.PortalServlet?IID=viewGrade' ,isFolder: false}
							]
							},
							{title: "Assignment Administration",isFolder: true,url:'',
							children: [
								{title:'Assignment Management',url:'./interfaceenginev2.PortalServlet?IID=CourseAssignMgmtAdmin' ,isFolder: false},
								{title:'Assignment Document Management',url:'./interfaceenginev2.PortalServlet?IID=CourseAssignDocMgmt' ,isFolder: false},
								{title:'Assignment Course Association',url:'./interfaceenginev2.PortalServlet?IID=CourseAssgnCourseAssoAdmin' ,isFolder: false},
								{title:'Assignment Feedback Management',url:'./interfaceenginev2.PortalServlet?IID=CourseAssignmentFeedbackManagement' ,isFolder: false}
							]
							},
							{title: "Catalog Management",isFolder: true,url:'',
							children: [
								{title:'Define Catalog',url:'./interfaceenginev2.PortalServlet?IID=CatalogMaster' ,isFolder: false},
								{title:'Catalog Association',url:'./interfaceenginev2.PortalServlet?IID=CatalogAssociation' ,isFolder: false}
							]
							},
							{title: "View Report",isFolder: true,url:'',
							children: [
							{title:'View Course Report',url:'./interfaceenginev2.PortalServlet?IID=courseReport' ,isFolder: false}
							
							]
							}		
							
						]
						},
						{title: "Assessment Management",isFolder: true,url:'',
						children: [
						{title: "Q B Administration",isFolder: true,url:'',
							children: [
								{title:'QB Management',url:'./interfaceenginev2.PortalServlet?IID=QBManagement' ,isFolder: false},
								{title:'QB Item Management',url:'./interfaceenginev2.PortalServlet?IID=QBItemManagement' ,isFolder: false},
								{title:'Help',url:'./interfaceenginev2.PortalServlet?IID=QBAdminHelp' ,isFolder: false}
							]
							},
							{title: "Assessment Administration",isFolder: true,url:'',	
							children: [
								{title:'Topic Management',url:'./interfaceenginev2.PortalServlet?IID=TopicManagement' ,isFolder: false},
								{title:'Question Bank Topic Association',url:'./interfaceenginev2.PortalServlet?IID=QBTopicAssociation' ,isFolder: false},
								{title:'Assessment Management',url:'./interfaceenginev2.PortalServlet?IID=AssessmentManagement' ,isFolder: false},
								{title:'Assessment Definition',url:'./interfaceenginev2.PortalServlet?IID=AssessmentDefinition' ,isFolder: false},
								{title:'Assessment Registration By User',url:'./interfaceenginev2.PortalServlet?IID=AssessmentRegByUser' ,isFolder: false},
								{title:'Assessment Registration By Group',url:'./interfaceenginev2.PortalServlet?IID=AssessmentRegByGroup' ,isFolder: false},
								//{title:'Assessment Alarm Management',url:'./interfaceenginev2.PortalServlet?IID=AssessmentAlarmManagement' ,isFolder: false},
								{title:'Assessment Result Notification Mgmt.',url:'./interfaceenginev2.PortalServlet?IID=AsmtResultNotificationMgmt' ,isFolder: false}
							]
							},
							{title: "Result Administration",isFolder: true,url:'',
							children: [
								{title:'Online Marking',url:'./interfaceenginev2.PortalServlet?IID=OnlineMarking' ,isFolder: false}	
							]
							},
							{title: "Assessment Reports",isFolder: true,url:'',
							children: [
								{title:'Assessments Result',url:'./interfaceenginev2.PortalServlet?IID=AssessmentsResult' ,isFolder: false},
								{title:'Assessment Registration Report',url:'./interfaceenginev2.PortalServlet?IID=AssessmentRegisReport' ,isFolder: false},
								{title:'Assessment Report Generation',url:'./interfaceenginev2.PortalServlet?IID=AsmtReportGeneration' ,isFolder: false},
								{title:'Assessment Details Report',url:'./interfaceenginev2.PortalServlet?IID=AsmtDetailsReport' ,isFolder: false},
								{title:'Assessments Report Summary',url:'./interfaceenginev2.PortalServlet?IID=AsmtReportSummary' ,isFolder: false},
								{title:'Top Five Toppers',url:'./interfaceenginev2.PortalServlet?IID=TopFiveToppers' ,isFolder: false}	
							]
							}
						]
						},
						{title: "Forum Administration",isFolder: true,url:'',
						children: [
							{title:'Forum Management',url:'./interfaceenginev2.PortalServlet?IID=ForumAdmin' ,isFolder: false},
							{title:'Message Management',url:'./interfaceenginev2.PortalServlet?IID=ForumMsgMgmt' ,isFolder: false},
							{title:'Forum Registration by User',url:'./interfaceenginev2.PortalServlet?IID=ForumRegByUser' ,isFolder: false},
							{title:'Forum Registration by Group',url:'./interfaceenginev2.PortalServlet?IID=ForumRegByGroup' ,isFolder: false},
							{title:'Forum Registration Confirmation',url:'./interfaceenginev2.PortalServlet?IID=ForumRegistrationConfirmation' ,isFolder: false},
							{title:'Forum Dynamic Information',url:'./interfaceenginev2.PortalServlet?IID=ForumDynamicInfo' ,isFolder: false},
							{title:'View Forum Report',url:'./interfaceenginev2.PortalServlet?IID=forumReport' ,isFolder: false},
							{title:'Help',url:'./interfaceenginev2.PortalServlet?IID=forumhelp' ,isFolder: false},
							{title:'Popular Forum Chart',url:'./interfaceenginev2.PortalServlet?IID=forumadminchart' ,isFolder: false}
						]
						},
						{title: "Collaboration",isFolder: true,url:'',
						children: [
						{title: "Synchronous Collaboration",isFolder: true,url:'',
							children: [
								{title:'Synchronous Collaboration Management',url:'./interfaceenginev2.PortalServlet?IID=scMgmt' ,isFolder: false},
								{title:'Streaming Configuration Management',url:'./interfaceenginev2.PortalServlet?IID=scStreamingConfMgmt' ,isFolder: false},
								{title:'Desktop Sharing',url:'./interfaceenginev2.PortalServlet?IID=scDesktopSharingPort' ,isFolder: false},
								{title:'Sync. Collaboration Registration Confirmation',url:'./interfaceenginev2.PortalServlet?IID=scRegConfirm' ,isFolder: false},
								{title:'Streaming Server Management',url:'./interfaceenginev2.PortalServlet?IID=scStreamingServ' ,isFolder: false},
								{title:'Sync. Collaboration Regt. By Group',url:'./interfaceenginev2.PortalServlet?IID=scRegByGroup' ,isFolder: false},
								{title:'Desktop Sharing Port for Server',url:'./interfaceenginev2.PortalServlet?IID=scDesktopServPort' ,isFolder: false},
								{title:'Streaming Configuration Management For Student',url:'./interfaceenginev2.PortalServlet?IID=scStudentStreaming' ,isFolder: false},
								{title:'User Registration Administration',url:'./interfaceenginev2.PortalServlet?IID=scUserReg' ,isFolder: false}
							]
							},
							{title: "Calendar Administration",isFolder: true,url:'',
							children: [
								{title:'Shared Calendar Management',url:'./interfaceenginev2.PortalServlet?IID=calMgmt' ,isFolder: false},
								{title:'Shared Calendar Regt. By User',url:'./interfaceenginev2.PortalServlet?IID=calRegUser' ,isFolder: false},
								{title:'Shared Calendar Regt. By Group',url:'./interfaceenginev2.PortalServlet?IID=calRegGroup' ,isFolder: false},
								{title:'Shared Calendar Entry Mgmt.',url:'./interfaceenginev2.PortalServlet?IID=calEntryMgmt' ,isFolder: false}
							]
							},
							{title: "NoteBook Administration",isFolder: true,url:'',
							children: [
								{title:'NoteBook Management',url:'./interfaceenginev2.PortalServlet?IID=NotebookMgmt' ,isFolder: false},
								{title:'Help',url:'./interfaceenginev2.PortalServlet?IID=NotebookHelp' ,isFolder: false}
							]
							}
						]
						},
						{title: "Notice Administration",isFolder: true,url:'',
							children: [
								{title:'Notice Board',url:'./interfaceenginev2.PortalServlet?IID=NoticeBoardAdmin' ,isFolder: false},
								{title:'Help',url:'./interfaceenginev2.PortalServlet?IID=NoticeHelp' ,isFolder: false}
							]
						},
// 						{title: "Report Import Export",isFolder: true,url:'',
// 						children: [
// 							{title:'Report Import Export',url:'./interfaceenginev2.PortalServlet?IID=ReportInpExp' ,isFolder: false},
// 							{title:'Matric Management',url:'./interfaceenginev2.PortalServlet?IID=Dashboard' ,isFolder: false}
// 						]
// 						},
						{title: "System Export",isFolder: true,url:'',
						children: [
						{title:'Export Import',url:'./interfaceenginev2.PortalServlet?IID=SystemExport' ,isFolder: false},
						{title:'Mail Server Configuration',url:'./interfaceenginev2.PortalServlet?IID=MailServerConfiguration' ,isFolder: false}
						]
						}
				]//main
		});
}

   function f12(dtnode) {
	   document.getElementById('ladminFrame').src = dtnode.data.url;
   }
   function logout_onclick() {
	   ladminTree.sessionInvalidate(function (data){
		   setValue('',data);
	   });
	   //document.LearnityAdminform.target = "_self";
	   window.location= "./interfaceenginev2.PortalServlet?IID=LoginPage";
	   //document.LearnityAdminform.submit() = "";
   }
   
   
//    function doUnload()
//    {
// 	   if (window.event.clientX < 0 && window.event.clientY < 0)
// 	   {
// 		   alert('close');
// 	   }
//    }
   
//    $(window).unload(function() {
// 	   doUnload();
//    });
   
//    function closeOut(){
// // 	   if (confirm("Do you really want to close this window")){
// // 		   return true; }
// // 		   location.href = document.URL;;
// // 		   return true;
// 	   alert('close');
//    }

   
   
// 	   $('#body').unload(function() {
// 		   alert('close');
// 	   });
	   
//    function doUnload()
//    {
// 	   var e = (window.event) ? window.event : evt;
// 
// 	   if (e.clientX < 0 && e.clientY < 0)
// 		   {
// 
// 			   alert("window closing....");
// 
// 		   }
//    }	   
	   
// 	   document.getElementsByTagName("body")[0].onunload=function s() {alert("s");}
//    $(window).unload(
// 		   function(){
// 	   alert("close");
//       //stop event
// 	   return false;
// 		   }
// );


/*window.onbeforeunload = function (evt) {
	var message = 'Are you sure you want to leave?';
	if (typeof evt == 'undefined') {
		evt = window.event;
	}
	if (evt) {
		evt.returnValue = message;
	}
	return message;
}*/ 