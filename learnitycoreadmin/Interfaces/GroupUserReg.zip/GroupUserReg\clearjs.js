
function dummyfunction() {};

function ClearSelectorValuesFromSession() {
	var namevaluepair;
	namevaluepair.push("group_id");
	namevaluepair.push("");
    PortalEngine.ChangeVectorGridLoadQuery("GroupUserReg","GroupUserRegGrid",namevaluepair,dummyfunction);
 };
 
  
 
